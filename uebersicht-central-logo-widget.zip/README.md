# uebersicht-central-logo-widget
## A Very simple script to display any image at the center of your screen.
First uebersicht widget, first github project, first coffeeScript, so a lot of typos and noob errors ahead. It works though...


![Screenshot](https://raw.githubusercontent.com/aykot/uebersicht-central-logo-widget/master/Screenshot.png)


Best results obtained with *.png files with transparency.

You need to have installed Übersicht to use this widget.

More info here [Übersicht](http://tracesof.net/uebersicht)
